﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bon_Apetit.BackEnd.Enums
{
    public enum EnumTypeDough
    {
        None,
        Puff,
        Crispy
    }
}
