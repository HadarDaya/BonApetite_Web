﻿
namespace Bon_Apetit.FrontEnd.UserControls
{
    partial class UserControlAddCake
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBoxTypeCake = new System.Windows.Forms.ComboBox();
            this.TypeOfCake = new System.Windows.Forms.Label();
            this.ComboBoxTemp = new System.Windows.Forms.ComboBox();
            this.EatingTemp = new System.Windows.Forms.Label();
            this.fruites = new System.Windows.Forms.CheckBox();
            this.choco = new System.Windows.Forms.CheckBox();
            this.comboBoxShapeT = new System.Windows.Forms.ComboBox();
            this.ShapeOfTray = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // comboBoxTypeCake
            // 
            this.comboBoxTypeCake.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTypeCake.ForeColor = System.Drawing.SystemColors.MenuText;
            this.comboBoxTypeCake.FormattingEnabled = true;
            this.comboBoxTypeCake.Location = new System.Drawing.Point(242, 217);
            this.comboBoxTypeCake.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBoxTypeCake.Name = "comboBoxTypeCake";
            this.comboBoxTypeCake.Size = new System.Drawing.Size(170, 33);
            this.comboBoxTypeCake.TabIndex = 22;
            // 
            // TypeOfCake
            // 
            this.TypeOfCake.AutoSize = true;
            this.TypeOfCake.Font = new System.Drawing.Font("Palatino Linotype", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TypeOfCake.ForeColor = System.Drawing.Color.White;
            this.TypeOfCake.Location = new System.Drawing.Point(16, 217);
            this.TypeOfCake.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.TypeOfCake.Name = "TypeOfCake";
            this.TypeOfCake.Size = new System.Drawing.Size(156, 29);
            this.TypeOfCake.TabIndex = 21;
            this.TypeOfCake.Text = "* Type of cake:";
            // 
            // ComboBoxTemp
            // 
            this.ComboBoxTemp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBoxTemp.ForeColor = System.Drawing.SystemColors.MenuText;
            this.ComboBoxTemp.FormattingEnabled = true;
            this.ComboBoxTemp.Location = new System.Drawing.Point(242, 98);
            this.ComboBoxTemp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ComboBoxTemp.Name = "ComboBoxTemp";
            this.ComboBoxTemp.Size = new System.Drawing.Size(170, 33);
            this.ComboBoxTemp.TabIndex = 18;
            // 
            // EatingTemp
            // 
            this.EatingTemp.AutoSize = true;
            this.EatingTemp.Font = new System.Drawing.Font("Palatino Linotype", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EatingTemp.ForeColor = System.Drawing.Color.White;
            this.EatingTemp.Location = new System.Drawing.Point(16, 98);
            this.EatingTemp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.EatingTemp.Name = "EatingTemp";
            this.EatingTemp.Size = new System.Drawing.Size(214, 29);
            this.EatingTemp.TabIndex = 17;
            this.EatingTemp.Text = "* Eating temprature:";
            // 
            // fruites
            // 
            this.fruites.AutoSize = true;
            this.fruites.Font = new System.Drawing.Font("Palatino Linotype", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fruites.ForeColor = System.Drawing.Color.White;
            this.fruites.Location = new System.Drawing.Point(330, 29);
            this.fruites.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.fruites.Name = "fruites";
            this.fruites.Size = new System.Drawing.Size(162, 33);
            this.fruites.TabIndex = 16;
            this.fruites.Text = "Has fruites?";
            this.fruites.UseVisualStyleBackColor = true;
            // 
            // choco
            // 
            this.choco.AutoSize = true;
            this.choco.Font = new System.Drawing.Font("Palatino Linotype", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.choco.ForeColor = System.Drawing.Color.White;
            this.choco.Location = new System.Drawing.Point(20, 29);
            this.choco.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.choco.Name = "choco";
            this.choco.Size = new System.Drawing.Size(199, 33);
            this.choco.TabIndex = 15;
            this.choco.Text = "Has chocolate? ";
            this.choco.UseVisualStyleBackColor = true;
            // 
            // comboBoxShapeT
            // 
            this.comboBoxShapeT.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxShapeT.ForeColor = System.Drawing.SystemColors.MenuText;
            this.comboBoxShapeT.FormattingEnabled = true;
            this.comboBoxShapeT.Location = new System.Drawing.Point(242, 160);
            this.comboBoxShapeT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBoxShapeT.Name = "comboBoxShapeT";
            this.comboBoxShapeT.Size = new System.Drawing.Size(170, 33);
            this.comboBoxShapeT.TabIndex = 20;
            // 
            // ShapeOfTray
            // 
            this.ShapeOfTray.AutoSize = true;
            this.ShapeOfTray.Font = new System.Drawing.Font("Palatino Linotype", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShapeOfTray.ForeColor = System.Drawing.Color.White;
            this.ShapeOfTray.Location = new System.Drawing.Point(16, 160);
            this.ShapeOfTray.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ShapeOfTray.Name = "ShapeOfTray";
            this.ShapeOfTray.Size = new System.Drawing.Size(165, 29);
            this.ShapeOfTray.TabIndex = 19;
            this.ShapeOfTray.Text = "* Shape of tray:";
            // 
            // UserControlAddCake
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.comboBoxTypeCake);
            this.Controls.Add(this.TypeOfCake);
            this.Controls.Add(this.comboBoxShapeT);
            this.Controls.Add(this.ShapeOfTray);
            this.Controls.Add(this.ComboBoxTemp);
            this.Controls.Add(this.EatingTemp);
            this.Controls.Add(this.fruites);
            this.Controls.Add(this.choco);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "UserControlAddCake";
            this.Size = new System.Drawing.Size(502, 285);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxTypeCake;
        private System.Windows.Forms.Label TypeOfCake;
        private System.Windows.Forms.ComboBox ComboBoxTemp;
        private System.Windows.Forms.Label EatingTemp;
        private System.Windows.Forms.CheckBox fruites;
        private System.Windows.Forms.CheckBox choco;
        private System.Windows.Forms.ComboBox comboBoxShapeT;
        private System.Windows.Forms.Label ShapeOfTray;
    }
}
